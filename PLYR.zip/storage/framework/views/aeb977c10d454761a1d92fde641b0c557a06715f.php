<!-- Hero -->
<div class="bg-body-light">
    <div class="content content-full">
        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
            <h1 class="flex-sm-fill h3 my-2"><?php echo $__env->yieldContent('title-page'); ?></h1>
            <nav class="flex-sm-00-auto ml-sm-3" aria-label="breadcrumb">
                <?php if(count($breadcrumbs)): ?>
                <ol class="breadcrumb">
                    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($breadcrumb->url && !$loop->last): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e($breadcrumb->url); ?>"><?php echo e($breadcrumb->title); ?></a></li>
                    <?php else: ?>
                    <li class="breadcrumb-item active"><?php echo e($breadcrumb->title); ?></li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
                <?php endif; ?>
<!--                <ol class="breadcrumb breadcrumb-alt">
                    <li class="breadcrumb-item">App</li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a class="link-fx" href="">Dashboard</a>
                    </li>
                </ol>-->
            </nav>
        </div>
    </div>
</div>
<!-- END Hero --><?php /**PATH D:\xampp\htdocs\PLYR\resources\views/layouts/admin/breadcrumbs.blade.php ENDPATH**/ ?>