<?php $__env->startSection('content'); ?>
<!-- Subir documento -->
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<link rel="stylesheet" href="<?php echo e(asset('/css/dropzone.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/css/basic.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/css/plyr.css')); ?>">
<script src="<?php echo e(asset('js/dropzone.js')); ?>"></script>
<script src="<?php echo e(asset('js/pages/dropzone.js')); ?>"></script>
<script src="<?php echo e(asset('js/plyr.js')); ?>"></script>
<script src="<?php echo e(asset('js/pages/viewGroup.js')); ?>"></script>
<?php $__env->startSection('title-page'); ?>
<?php echo e(__($proyect_data[0]['proyect_name'])); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
<?php echo e(Breadcrumbs::render('group.view', $proyect_data[0]['proyect_name'])); ?>

<?php $__env->stopSection(); ?> 
<!-- Hero Content -->
<div class="bg-image" style="background-image: url('<?php echo e(asset("/media/photos/photo23@2x.jpg")); ?>');">
     <div class="bg-primary-op">
        <div class="content content-full overflow-hidden">
            <div class="my-8 text-center">
                <div class="my-3">
                    <img class="img-avatar img-avatar-thumb" src="<?php echo e(asset($compamy[0]['company_url_logo'])); ?>" alt="">
                </div>
                <h1 class="text-white mb-2 invisible" data-toggle="appear" data-class="animated fadeInDown"><?php echo e($user[0]['company']); ?></h1>
                <h2 class="h4 font-w400 text-white-75 invisible" data-toggle="appear" data-class="animated fadeInDown"><?php echo e($proyect_data[0]['proyect_description']); ?></h2>
            </div>
        </div>
    </div>
</div>
<!-- END Hero Content -->
<div class="bg-white">
    <div class="content content-boxed">
        <div class="row justify-content-md-center">
            <div class="col-10">
                <button type="button" class="btn btn-lg btn-primary js-tooltip-enabled form-control" data-toggle="tooltip" title="" data-original-title="Remove Client">
                    <i class="fa fa-fw fa-share-square"></i>
                </button>
            </div>
        </div>
    </div>
</div>
<!-- Page Content -->
<div class="bg-white">
    <div class="content content-boxed">
        <div class="row">
            <div class="col-12">
                <div class="block block-rounded">
                    <div class="block-header">
                        <h3 class="block-title">Group Team</h3>
                        <?php if(Helper::validUserPropertyGroup(Auth::id(), $proyect_data[0]['proyect_name'])): ?>
                        <div class="float-right col-md-1">
                            <a href="<?php echo e(route('group.user.create', $proyect_data[0]['id'])); ?>"> <button type="button" class="mb-3 mr-1 btn btn-info">
                                    <i class="fa fa-fw fa-<?php echo e(__('bts.add-icon')); ?>"></i> <?php echo e(__('bts.add')); ?>

                                </button></a>
                        </div>
                        <?php endif; ?>
                        <div class="block-options">
                            <div class="block-options-item">
                            </div>
                        </div>
                    </div>
                    <div class="block-content">
                        <table class="table table-sm table-vcenter">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('users.name_full')); ?></th>
                                    <th class="d-none d-sm-table-cell" style="width: 15%;"><?php echo e(__('users.position')); ?></th>
                                    <th class="d-none d-sm-table-cell" style="width: 15%;"><?php echo e(__('users.email')); ?></th>
                                    <th class="d-none d-sm-table-cell" style="width: 15%;"><?php echo e(__('users.movil')); ?></th>
                                    <th class="d-none d-sm-table-cell" style="width: 15%;"><?php echo e(__('users.phone')); ?></th>
                                    <?php if(Helper::validUserPropertyGroup(Auth::id(), $proyect_data[0]['proyect_name'])): ?>
                                    <th class="text-center" style="width: 100px;"><?php echo e(__('proyects.acctions')); ?></th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="font-w600 font-size-sm">
                                        <?php echo e($team_user['name']); ?>

                                    </td>
                                    <td class="font-w600 font-size-sm">
                                        <?php echo e($team_user['position']); ?>

                                    </td>
                                    <td class="font-w600 font-size-sm">
                                        <?php echo e($team_user['email']); ?>

                                    </td>
                                    <td class="font-w600 font-size-sm">
                                        <?php echo e($team_user['movil']); ?>

                                    </td>
                                    <td class="d-none d-sm-table-cell">
                                        <?php echo e($team_user['phone']); ?>

                                    </td>
                                    <?php if(Helper::validUserPropertyGroup(Auth::id(), $proyect_data[0]['proyect_name'])): ?>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-primary tooltip-bts" data-toggel="0" data-action="toltips-alert-acctions-user-<?php echo e($proyect_data[0]['id']); ?>"><?php echo e(__('bts.actions')); ?></button>
                                        <br>
                                        <div class="tooltip-bts-alerts-hidden tooltip-bts-alerts" id="toltips-alert-acctions-user-<?php echo e($proyect_data[0]['id']); ?>">
                                            <a href="<?php echo e(route('group.user.edit', ['id_group' => $proyect_data[0]['id'], 'id' => $team_user['id']])); ?>" class="btn btn-sm btn-light js-tooltip-enabled" data-toggle="tooltip" title="" data-original-title="Edit Client">
                                                <i class="fa fa-fw fa-pencil-alt"></i>
                                            </a>
                                            <br>
                                            <a href="<?php echo e(route('group.user.remove', ['id_group'=>$proyect_data[0]['id'], 'id_user'=>$team_user['id']])); ?>" class="btn btn-sm btn-light js-tooltip-enabled users-delete" data-toggle="tooltip" title="" data-original-title="Remove Client">
                                                <i class="fa fa-fw fa-times"></i>
                                            </a>
                                            <?php if($listGroups): ?>
                                            <br>
                                            <button type="button" class="btn btn-sm btn-light js-tooltip-enabled push bt-modal-share" data-toggle="modal" data-target="#modal-block-popin" data-user="<?php echo e($team_user['id']); ?>">
                                                <i class="fa fa-fw fa-share-square"></i>
                                            </button>
                                            <?php endif; ?>
                                            <!--                                            <a href="<?php echo e(route('group.user.share', $team_user['id'])); ?>" class="btn btn-sm btn-light js-tooltip-enabled push" data-toggle="modal" title="" data-target="#modal-block-popin" data-original-title="shared Client">
                                                                                            <i class="fa fa-fw fa-share-square"></i>
                                                                                        </a>-->
                                        </div>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php if(Helper::validUserPropertyGroup(Auth::id(), $proyect_data[0]['proyect_name'])): ?>
        <div class="row">
            <div class="col-12">
                <?php echo Form::open(['route'=> 'group.file', 'method' => 'POST', 'files'=>'true', 'id' => 'my-dropzone' , 'class' => 'dropzone']); ?>

                <div class="dz-message" style="height:200px;">
                    Drop your files here
                    <br>
                    Maximum weight per file is 20 MG
                    <br>
                    10 files at a time per upload
                    <br>
                    Only allows documents (word, excel and pdf) and images
                </div>
                <div class="dropzone-previews"></div>
                <?php echo e(Form::hidden('id_group', $proyect_data[0]['id'])); ?>

                <?php echo Form::close(); ?>


            </div>
        </div>
        <?php endif; ?>
        <br><br>
        <div class="row">
            <div class="col-12">
                <div class="block block-rounded">
                    <div class="block-header">
                        <h3 class="block-title">Files</h3>
                        <div class="block-options">
                            <div class="block-options-item">
                            </div>
                        </div>
                    </div>
                    <div class="block-content">
                        <table class="table table-sm table-vcenter">
                            <thead>
                                <tr>
                                    <th class="text-center" style="width: 50px;">#</th>
                                    <th>Name</th>
                                    <th class="d-none d-sm-table-cell" style="width: 15%;">Access</th>
                                    <?php if(Helper::validUserPropertyGroup(Auth::id(), $proyect_data[0]['proyect_name'])): ?>
                                    <th class="text-center" style="width: 100px;">Actions</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyFile => $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="text-center" scope="row"><?php echo e($keyFile+1); ?></th>
                                    <td class="font-w600 font-size-sm">
                                        <a href="<?php echo e(url($file['document_url'])); ?>" target="_blanck"><?php echo e($file['document_name']); ?></a>
                                    </td>
                                    <td class="d-none d-sm-table-cell">
                                        <span class="badge badge-warning">Trial</span>
                                    </td>
                                    <?php if(Helper::validUserPropertyGroup(Auth::id(), $proyect_data[0]['proyect_name'])): ?>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-primary tooltip-bts" data-toggel="0" data-action="toltips-alert-acctions-<?php echo e($file['id']); ?>"><?php echo e(__('bts.actions')); ?></button>
                                        <br>
                                        <div class="tooltip-bts-alerts-hidden tooltip-bts-alerts" id="toltips-alert-acctions-<?php echo e($file['id']); ?>">
                                            <a href="<?php echo e(route('group.file.delite', $file['id'])); ?>" class="btn btn-sm btn-light js-tooltip-enabled document-destroy" data-toggle="tooltip" title="" data-original-title="Remove Client">
                                                <i class="fa fa-fw fa-times"></i>
                                            </a>
                                            <br>
                                            <a href="<?php echo e(url($file['document_url'])); ?>" target="_black" class="btn btn-sm btn-light js-tooltip-enabled" data-toggle="tooltip" title="" data-original-title="download file" download>                                                <i class="fa fa-fw fa-download"></i>
                                            </a>
                                            <?php if($listGroups): ?>
                                            <br>
                                            <button type="button" class="btn btn-sm btn-light js-tooltip-enabled push bt-modal-file-share" data-toggle="modal" data-target="#modal-block-file-group" data-file="<?php echo e($file['id']); ?>">
                                                <i class="fa fa-fw fa-share-square"></i>
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END Page Content -->

<?php $__env->startComponent('components.modal.formSharedUserGroup'); ?>    

<?php $__env->slot('title'); ?>
Share user in another group
<?php $__env->endSlot(); ?>
<div class="block-content">
    <?php echo e(Form::hidden('user_id_share', $proyect_data[0]['id'],['id'=>'user_id_share'])); ?>

    <?php echo e(Form::hidden('company_id_share', $compamy[0]['id'],['id'=>'company_id_share'])); ?>

    <div class="form-group">
        <?php echo e(Form::label('group', 'Select group to share', ['class' => 'control-label'])); ?>

        <?php echo e(Form::select('group', $listGroups, null, ['class' => 'form-control'])); ?>

    </div>
</div>
<?php if (isset($__componentOriginalbf1318c764e90d56ee7a76447d198fc9584de89b)): ?>
<?php $component = $__componentOriginalbf1318c764e90d56ee7a76447d198fc9584de89b; ?>
<?php unset($__componentOriginalbf1318c764e90d56ee7a76447d198fc9584de89b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('components.modal.formSharedFileGroup'); ?>    

<?php $__env->slot('title'); ?>
Share user in another group
<?php $__env->endSlot(); ?>
<div class="block-content">
    <?php echo e(Form::hidden('file_id_share', $proyect_data[0]['id'],['id'=>'file_id_share'])); ?>

    <?php echo e(Form::hidden('company_id_share', $compamy[0]['id'],['id'=>'company_id_share'])); ?>

    <div class="form-group">
        <?php echo e(Form::label('group', 'Select group to share', ['class' => 'control-label'])); ?>

        <?php echo e(Form::select('group', $listGroups, null, ['class' => 'form-control'])); ?>

    </div>
</div>
<?php if (isset($__componentOriginalb30b0d97c7f1ddaf691cb59ab4e753df69f35b08)): ?>
<?php $component = $__componentOriginalb30b0d97c7f1ddaf691cb59ab4e753df69f35b08; ?>
<?php unset($__componentOriginalb30b0d97c7f1ddaf691cb59ab4e753df69f35b08); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('js_after'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PLYR\resources\views/admin/proyects/views.blade.php ENDPATH**/ ?>