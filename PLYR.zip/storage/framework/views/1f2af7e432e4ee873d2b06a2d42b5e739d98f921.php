<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title-page'); ?>
<?php echo e(__('proyects.name')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
<?php echo e(Breadcrumbs::render('Groups')); ?>

<?php $__env->stopSection(); ?>
<!-- Dynamic Table with Export Buttons -->
<div class="block block-rounded">

    <div class="block-content block-content-full">
        <!-- DataTables init on table by adding .js-dataTable-buttons class, functionality is initialized in js/pages/be_tables_datatables.min.js which was auto compiled from _js/pages/be_tables_datatables.js -->
        <div class="float-right col-md-1">
            <a href="<?php echo e(route('groups.create')); ?>"> <button type="button" class="mb-3 mr-1 btn btn-info">
                    <i class="fa fa-fw fa-<?php echo e(__('bts.add-icon')); ?>"></i> <?php echo e(__('bts.add')); ?>

                </button></a>
        </div>
        <table class="table table-bordered table-striped table-vcenter js-dataTable-buttons">
            <thead>
                <tr>
                    <th class="text-center" style="width: 80px;">#</th>
                    <th><?php echo e(__('proyects.nameProyects')); ?></th>
                    <th><?php echo e(__('proyects.description')); ?></th>
                    <th><?php echo e(__('proyects.start_date')); ?></th>
                    <th><?php echo e(__('proyects.end_date')); ?></th>
                    <th><?php echo e(__('proyects.user')); ?></th>
                    <th><?php echo e(__('proyects.upload_file')); ?></th>
                    <th style="width: 11,25%;"><?php echo e(__('proyects.acctions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $proyects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center font-size-sm"><?php echo e($proyect->id); ?></td>
                    <td class="font-w600 font-size-sm">
                        <?php echo e($proyect->proyect_name); ?>

                    </td>
                    <td class="font-w600 font-size-sm">
                        <?php echo e($proyect->proyect_description); ?>

                    </td>
                    <td class="font-w600 font-size-sm">
                        <?php echo e($proyect->proyect_start); ?>

                    </td>
                    <td class="font-w600 font-size-sm">
                        <?php echo e($proyect->proyect_end); ?>

                    </td>
                    <td class="font-w600 font-size-sm">
                        <?php echo e(Helper::dataUserName($proyect->user_id)); ?>

                    </td>
                    <td class="font-w600 font-size-sm">
                        <a href="/group/<?php echo e($proyect->proyect_url); ?>" class="mb-3 mr-1 btn btn-warning">
                            <i class="fa fa-file-upload"></i>
                        </a>
                    </td>
                    <td>
                        <a href="/group/<?php echo e($proyect->proyect_url); ?>" class="mb-3 mr-1 btn btn-warning">
                            <i class="fa fa-fw fa-eye"></i>
                        </a> &nbsp;
                        <a href="<?php echo e(route('groups.edit',$proyect->id)); ?>" class="mb-3 mr-1 btn btn-info">
                            <i class="fa fa-fw fa-pencil-alt"></i>
                        </a> &nbsp;
                        <form method="POST" action=""
                              style="display:inline;">
                            <?php echo e(csrf_field()); ?> <?php echo e(method_field('groups.delete')); ?>

                            <button class="mb-3 mr-1 btn btn-danger"
                                    onclick="return confirm('<?php echo e(__('proyects.alert_delete')); ?>')"><i
                                    class="fa fa-fw fa-times"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<!-- END Dynamic Table with Export Buttons -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js_after'); ?>
<!-- Page JS Plugins -->
<script src="<?php echo e(asset('js/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/datatables/buttons/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/datatables/buttons/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/datatables/buttons/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/datatables/buttons/buttons.flash.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/datatables/buttons/buttons.colVis.min.js')); ?>"></script>

<!-- Page JS Code -->
<script src="<?php echo e(asset('js/pages/be_tables_datatables.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PLYR\resources\views/admin/proyects/index.blade.php ENDPATH**/ ?>