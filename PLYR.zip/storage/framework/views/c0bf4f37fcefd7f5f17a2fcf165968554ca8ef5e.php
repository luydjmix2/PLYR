<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title-page'); ?>
<?php echo e(__('proyects.name')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
<?php echo e(Breadcrumbs::render(__('proyects.name').'.create')); ?>

<?php $__env->stopSection(); ?>

<!-- Form Wizards (.js-wizard-* classes are initialized in js/pages/be_forms_wizard.min.js which was auto compiled from _js/pages/be_forms_wizard.js) -->
<!-- For more examples you can check out https://github.com/VinceG/twitter-bootstrap-wizard -->

<!-- Progress Wizards -->
<div class="row">
    <div class="col-md-12">
            <div class="block-content">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php echo Form::open(['route'=> 'groups.store', 'method' => 'POST', 'files'=>'true', 'id' => 'proyectCreate' ]); ?>

                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <?php echo e(Form::label('wizard-progress-name', __('proyects.nameProyects'))); ?>

                    <?php echo e(Form::text('proyect_name',old('proyect_name'), ['class'=>'form-control'])); ?>

                </div>
                <div class="form-group">                        
                    <?php echo e(Form::label('wizard-progress-name', __('proyects.description'))); ?>

                    <?php echo e(Form::textarea('proyect_description',old('proyect_name'), ['class'=>'form-control', 'row'=> '8'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('wizard-progress-name', __('proyects.start_date'))); ?>

                    <?php echo e(Form::date('proyect_start', \Carbon\Carbon::now(),['class'=>'form-control'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('wizard-progress-name', __('proyects.end_date'))); ?>

                    <?php echo e(Form::date('proyect_end', \Carbon\Carbon::tomorrow(), ['class'=>'form-control'])); ?>

                </div>
                <?php echo e(Form::hidden('user_id', '1')); ?>

                <div class="mb-2 text-right col-12">

                    <?php echo e(Form::button('<i class="fa fa-archive"></i> Create', ['type' => 'submit', 'id' => 'submit', 'class' => 'btn btn-primary'])); ?>

                </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>

</div>
<!-- END Progress Wizards -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_after'); ?> 

<script src="<?php echo e(asset('js/plugins/jquery-bootstrap-wizard/bs4/jquery.bootstrap.wizard.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/jquery-validation/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/jquery-validation/additional-methods.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PLYR\resources\views/admin/proyects/create.blade.php ENDPATH**/ ?>